function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0,204,0);
  fill(0,0,0);
  triangle(90, 355, 300, 30, 510, 355);
  fill(255, 255, 0);
  triangle(100, 350, 300, 40, 500, 350);
  fill(0,0,0);
  triangle(193, 198, 300, 355.3, 407, 198);
  fill(0,204,0);
  triangle(197, 200, 300, 355.3, 402, 200);
 
}