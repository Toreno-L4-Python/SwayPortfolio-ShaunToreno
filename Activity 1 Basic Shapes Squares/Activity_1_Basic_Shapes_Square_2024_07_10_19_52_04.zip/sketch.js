function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  fill(135, 206, 235)
  square(25,25,350)
  
  fill(255,0,0)
  square(50,50,50);
  square(175,50,50);
  square(300,50,50);
  
  fill(255,255,0)
  square(50,175,50);
  square(175,175,50);
  square(300,175,50);
  
  fill(0,255,0)
  square(50,300,50);
  square(175,300,50);
  square(300,300,50);
  
}