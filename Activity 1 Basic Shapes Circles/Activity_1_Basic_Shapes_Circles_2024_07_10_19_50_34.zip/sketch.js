function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  fill(0);
  circle(200,200,350);
  fill(255);
  circle(200,200,345);
  fill(0);
  circle(200,200,290);
  fill(255);
  circle(200,200,285);
  fill(0);
  circle(200,200,230);
  fill(255);
  circle(200,200,225);
  fill(0);
  circle(200,200,170);
  fill(255);
  circle(200,200,165);
  fill(0);
  circle(200,118,30);
  fill(0);
  circle(312,200,30);
  fill(0);
  circle(200,343,30);
  fill(0);
  circle(27,200,30);
  
  
}